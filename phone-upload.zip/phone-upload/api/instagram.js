// Vercel serverless function: fetches your latest Instagram posts.
//
// Setup (one time):
// 1. Go to https://developers.facebook.com → create an app → add "Instagram" product
//    (Instagram API with Instagram Login, a.k.a. Basic Display flow).
// 2. Add your @peace.over.popularity account as an Instagram tester and generate
//    a long-lived access token.
// 3. In Vercel → Project → Settings → Environment Variables, add:
//       INSTAGRAM_ACCESS_TOKEN = <your long-lived token>
// 4. Redeploy. The site will now pull your real posts automatically.
//
// Long-lived tokens last ~60 days. Refresh them with:
// https://graph.instagram.com/refresh_access_token?grant_type=ig_refresh_token&access_token=TOKEN

export default async function handler(req, res) {
  const token = process.env.INSTAGRAM_ACCESS_TOKEN;

  if (!token) {
    return res.status(200).json({
      configured: false,
      message: "INSTAGRAM_ACCESS_TOKEN is not set in Vercel environment variables.",
      posts: []
    });
  }

  try {
    const fields = "id,caption,media_type,media_url,thumbnail_url,permalink,timestamp";
    const url = `https://graph.instagram.com/me/media?fields=${fields}&limit=8&access_token=${token}`;
    const r = await fetch(url);
    const data = await r.json();

    if (data.error) {
      return res.status(200).json({ configured: true, error: data.error.message, posts: [] });
    }

    const posts = (data.data || [])
      .filter(p => p.media_type !== "VIDEO" || p.thumbnail_url)
      .slice(0, 4)
      .map(p => ({
        id: p.id,
        image: p.media_type === "VIDEO" ? p.thumbnail_url : p.media_url,
        caption: p.caption ? p.caption.slice(0, 100) : "",
        link: p.permalink
      }));

    // Cache at the edge for 30 minutes so we don't hammer the API
    res.setHeader("Cache-Control", "s-maxage=1800, stale-while-revalidate=3600");
    return res.status(200).json({ configured: true, posts });
  } catch (err) {
    return res.status(200).json({ configured: true, error: "Fetch failed", posts: [] });
  }
}
